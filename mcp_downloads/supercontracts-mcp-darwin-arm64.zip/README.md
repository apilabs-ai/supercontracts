# SuperContracts MCP v1.2.4

## Quick start

1. Unzip this archive.
2. Run the server:

```bash
./supercontracts-mcp-darwin-arm64
```

3. Generate an MCP token in API Labs → MCP Tokens.
4. Add to `.cursor/mcp.json`:

```json
{
  "mcpServers": {
    "supercontracts": {
      "url": "http://127.0.0.1:8080/mcp",
      "headers": {
        "Authorization": "Bearer <mcp_token>"
      }
    }
  }
}
```

## Optional environment overrides

| Variable | Release default |
|----------|-----------------|
| `APILABS_BASE_URL` | `https://app.apilabs.ai` (baked into this binary) |
| `APILABS_BACKEND_AUTH_MODE` | `bearer_header` |
| `APILABS_MCP_PORT` | `8080` |

Health: `http://127.0.0.1:8080/health`
MCP: `http://127.0.0.1:8080/mcp`
